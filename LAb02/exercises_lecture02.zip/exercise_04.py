# Notebook 4: Virtual Memory - When RAM Runs Out

import numpy as np
import os
import psutil

# Function to get current memory usage
def get_memory_usage():
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / (1024 * 1024)  # Convert to MB

# Display initial memory usage
print(f"Initial Memory Usage: {get_memory_usage():.2f} MB")

# Allocate a large array to simulate high RAM usage
try:
    large_array = np.random.rand(500000000)  # ~4GB in RAM
    print(f"Memory Usage After Allocation: {get_memory_usage():.2f} MB")
except MemoryError:
    print("MemoryError: Not enough RAM! Using disk instead.")
    with open("large_array.npy", "wb") as f:
        np.save(f, np.random.rand(500000000))
    print("Data saved to disk as virtual memory (swap).")

# Notebook Explanation:
# - This notebook simulates high RAM usage to demonstrate virtual memory behavior.
# - If RAM is insufficient, data is stored on disk instead (swap space).
# - Try adjusting the array size to see when your system starts using virtual memory.