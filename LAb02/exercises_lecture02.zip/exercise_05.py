# Notebook 5: Swap Space - Using Disk as Extended RAM

import os
import psutil
import numpy as np
import time


# Function to get current memory and swap usage
def get_memory_swap_usage():
    virtual_mem = psutil.virtual_memory()
    swap_mem = psutil.swap_memory()
    return virtual_mem.used / (1024 * 1024), swap_mem.used / (1024 * 1024)  # Convert to MB


# Display initial memory and swap usage
mem_before, swap_before = get_memory_swap_usage()
print(f"Memory Usage Before Allocation: {mem_before:.2f} MB")
print(f"Swap Usage Before Allocation: {swap_before:.2f} MB")

# Attempt to allocate a very large array to force swap usage
try:
    large_array = np.random.rand(1000000000)  # ~8GB in RAM
    time.sleep(5)  # Allow time to observe swap usage
    mem_after, swap_after = get_memory_swap_usage()
    print(f"Memory Usage After Allocation: {mem_after:.2f} MB")
    print(f"Swap Usage After Allocation: {swap_after:.2f} MB")
except MemoryError:
    print("MemoryError: Not enough RAM! Swap space may be used if enabled.")

# Notebook Explanation:
# - This notebook demonstrates swap space usage when RAM is exhausted.
# - If RAM is full, the system moves inactive memory pages to disk (swap space).
# - Try adjusting the array size to observe changes in swap usage.