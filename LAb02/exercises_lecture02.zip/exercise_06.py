# Notebook 6: Performance Tuning - Optimizing Memory and Disk Usage

import numpy as np
import psutil
import os
import time
import gc

# Function to get memory usage
def get_memory_usage():
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / (1024 * 1024)  # Convert to MB

# Generate large data efficiently
print("Generating large dataset efficiently...")
start_time = time.time()
data = np.random.rand(10000000).astype(np.float32)  # Use float32 instead of float64
end_time = time.time()
print(f"Time taken: {end_time - start_time:.6f} seconds")
print(f"Memory Usage: {get_memory_usage():.2f} MB")

# Optimize disk I/O with memory mapping
print("\nOptimizing disk access using memory mapping...")
np.save("large_array.npy", data)

start_time = time.time()
mmap_data = np.load("large_array.npy", mmap_mode='r')
end_time = time.time()
print(f"Time taken to load with memory mapping: {end_time - start_time:.6f} seconds")

# Garbage Collection and Memory Cleanup
print("\nCleaning up memory...")
del data  # Delete variable

gc.collect()  # Force garbage collection
print(f"Memory Usage after cleanup: {get_memory_usage():.2f} MB")

# Notebook Explanation:
# - Uses `float32` instead of `float64` to reduce memory consumption.
# - Uses memory mapping (`mmap_mode='r'`) to avoid loading large files into RAM.
# - Implements garbage collection to free up memory and improve performance.