# Notebook 7: Sequential vs Parallel Processing

import time
import multiprocessing

# Function to simulate a heavy computation
def heavy_computation(n):
    result = sum(i * i for i in range(n))
    return result

# Sequential Processing
n = 10**6
print("Running in sequential mode...")
start_time = time.time()
results_seq = [heavy_computation(n) for _ in range(4)]
end_time = time.time()
print(f"Sequential execution time: {end_time - start_time:.2f} seconds")

# Parallel Processing
print("\nRunning in parallel mode...")
if __name__ == "__main__":
    pool = multiprocessing.Pool(processes=4)  # Use 4 processes
    start_time = time.time()
    results_parallel = pool.map(heavy_computation, [n] * 4)
    pool.close()
    pool.join()
    end_time = time.time()
    print(f"Parallel execution time: {end_time - start_time:.2f} seconds")

# Notebook Explanation:
# - The notebook compares sequential and parallel execution for a CPU-intensive task.
# - Sequential processing runs tasks one after another.
# - Parallel processing uses `multiprocessing` to execute tasks simultaneously.
# - Compare execution times to see the efficiency gain of parallelism.