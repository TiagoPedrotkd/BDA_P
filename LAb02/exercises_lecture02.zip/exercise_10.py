"""
# Master-Slave Architecture Explained

## Overview
Master-Slave architecture is a design pattern used in distributed computing, databases, and parallel processing. The master node controls and delegates tasks to slave nodes, which execute the assigned work and return results to the master.

### Use Cases:
- **Databases**: Replication (e.g., MySQL, PostgreSQL)
- **Parallel Processing**: Distributed computing clusters (e.g., Hadoop, Spark)
- **Hardware Systems**: Master controllers managing subordinate processors

---
"""

# Import required libraries
import multiprocessing
import time


def slave_task(task_id):
    """Function executed by slave nodes."""
    print(f"Slave {task_id} processing task...")
    time.sleep(2)
    return f"Task {task_id} completed"


def master_process():
    """Master node distributing tasks to slaves."""
    num_slaves = 3  # Number of slave processes
    with multiprocessing.Pool(num_slaves) as pool:
        task_ids = range(1, num_slaves + 1)
        results = pool.map(slave_task, task_ids)

    print("Master received results:")
    for result in results:
        print(result)


# Run the master process
if __name__ == "__main__":
    master_process()
"""
## Explanation of Code:
1. The **Master** process initializes a pool of slave processes.
2. The **Slave** processes execute assigned tasks and return results.
3. The **Master** collects and displays results.

---
## Advantages of Master-Slave Architecture
- **Parallel Execution**: Tasks can be processed simultaneously.
- **Load Distribution**: The master ensures workload balancing.
- **Fault Tolerance**: If a slave fails, the master can reassign tasks.

## Disadvantages
- **Single Point of Failure**: If the master fails, the entire system may stop functioning.
- **Scalability Limits**: A single master may become a bottleneck in large systems.

---
## Real-World Example
### **Database Replication**
- **Master**: Handles writes, updates, and changes.
- **Slaves**: Read-only copies that sync from the master.

---
## Conclusion
Master-Slave architecture is widely used in distributed systems, ensuring efficiency and fault tolerance. 
However, alternative models such as **Master-Master** and **Peer-to-Peer** architectures are sometimes preferred
to avoid central bottlenecks.

"""
