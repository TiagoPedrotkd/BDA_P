# Notebook 9: Scale out vs Scale up
import matplotlib.pyplot as plt
import numpy as np

# Data for scaling methods
nodes = [1, 2, 4, 8]
cpu_power = [4, 8, 16, 32]  # Example CPU power scaling
throughput_scale_up = [100, 120, 140, 160]  # Scale-Up Performance
throughput_scale_out = [100, 200, 400, 800]  # Scale-Out Performance

fig, ax = plt.subplots(1, 2, figsize=(12, 5))

# Scale-Up Chart
ax[0].bar(nodes, throughput_scale_up, color='blue', alpha=0.7)
ax[0].set_title('Scale-Up (Vertical Scaling)')
ax[0].set_xlabel('CPU Power (Cores)')
ax[0].set_ylabel('Performance (Throughput)')
ax[0].set_xticks(nodes)
ax[0].grid(True, linestyle='--', alpha=0.5)

# Scale-Out Chart
ax[1].bar(nodes, throughput_scale_out, color='green', alpha=0.7)
ax[1].set_title('Scale-Out (Horizontal Scaling)')
ax[1].set_xlabel('Number of Nodes')
ax[1].set_ylabel('Performance (Throughput)')
ax[1].set_xticks(nodes)
ax[1].grid(True, linestyle='--', alpha=0.5)

plt.tight_layout()
plt.show()

print("Scale-Up (Vertical Scaling): Increasing the power of a single machine (e.g., adding more RAM, CPU, or storage).")
print("Scale-Out (Horizontal Scaling): Adding more machines (nodes) to distribute the load.")
