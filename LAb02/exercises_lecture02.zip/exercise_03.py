# Notebook 3: Caching - Speeding Up Disk Access Using RAM

import numpy as np
import time
import functools
import pickle

# Create a large dataset
large_array = np.random.rand(1000000)

# Function to simulate slow disk access
def read_from_disk():
    with open("large_array.pkl", "rb") as f:
        return pickle.load(f)

# Store the dataset on disk
with open("large_array.pkl", "wb") as f:
    pickle.dump(large_array, f)

# Measure time to read from disk
start_time = time.time()
disk_data = read_from_disk()
disk_time = time.time() - start_time
print(f"Time taken to read from disk: {disk_time:.6f} seconds")

# Use caching to speed up future reads
@functools.lru_cache(maxsize=1)
def cached_read():
    return read_from_disk()

# Measure time with caching
start_time = time.time()
cached_data = cached_read()
cached_time = time.time() - start_time
print(f"Time taken with caching: {cached_time:.6f} seconds")

# Notebook Explanation:
# - This notebook demonstrates how caching in RAM can speed up repeated disk reads.
# - The first read from disk is slow, but subsequent reads are much faster with caching.
# - Python's `functools.lru_cache()` is used to store the data in RAM for quick access.