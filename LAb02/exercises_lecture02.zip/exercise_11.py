"""
# Client-Server Architecture in Big Data

## Overview
Client-Server architecture is a design pattern used in networking, web applications, and distributed systems. In the context of **Big Data**, this architecture is crucial for managing, processing, and distributing vast amounts of data efficiently.

### Use Cases in Big Data:
- **Distributed Data Processing**: Apache Hadoop and Spark use a client-server model for data processing across multiple nodes.
- **Database Scaling**: Systems like Google BigQuery, Cassandra, and MongoDB use client-server models to handle large-scale data queries.
- **Cloud Computing**: Services like AWS, Google Cloud, and Azure operate with client-server structures to manage vast amounts of data requests.

---
"""

# Import required libraries
import socket


def server_program():
    """Function representing a big data server handling multiple clients."""
    host = '127.0.0.1'  # Localhost
    port = 5000  # Port to listen on
    server_socket = socket.socket()
    server_socket.bind((host, port))
    server_socket.listen(10)  # Support multiple clients
    print("Big Data Server is listening...")

    while True:
        conn, address = server_socket.accept()
        print(f"Connection from {address}")
        data = conn.recv(1024).decode()
        print(f"Received from client: {data}")
        conn.send(data.upper().encode())  # Simulating data processing
        conn.close()


def client_program():
    """Function representing a big data client."""
    host = '127.0.0.1'
    port = 5000
    client_socket = socket.socket()
    client_socket.connect((host, port))
    message = "Big Data Query"
    client_socket.send(message.encode())
    data = client_socket.recv(1024).decode()
    print(f"Received from server: {data}")
    client_socket.close()


# Run the server or client as needed
if __name__ == "__main__":
    choice = input("Run server (s) or client (c)? ")
    if choice.lower() == 's':
        server_program()
    else:
        client_program()
"""
## Explanation of Code:
1. The **Big Data Server** listens for multiple client connections and processes data requests.
2. The **Client** connects to the server, sends a query, and receives a processed response.
3. The architecture mimics distributed processing frameworks used in Big Data environments.

---
## Advantages of Client-Server Architecture in Big Data
- **Scalability**: Large-scale data processing across distributed servers.
- **Efficient Resource Management**: Clients offload heavy computations to powerful servers.
- **Centralized Control**: Enables monitoring and optimization of data processing.

## Disadvantages
- **Single Point of Failure**: If the central server crashes, data access is affected.
- **Latency**: High server load may lead to response delays in big data queries.

---
## Real-World Example
### **Apache Hadoop Model**
- **Client**: Submits jobs (MapReduce tasks, Spark queries)
- **Server (Master Node)**: Manages task scheduling, data allocation
- **Worker Nodes**: Process assigned tasks in parallel

---
## Conclusion
Client-Server architecture is foundational in **Big Data** processing, enabling efficient data storage, retrieval, and distributed computation. However, alternative models like **Peer-to-Peer (P2P)** and **Serverless Computing** are also gaining traction for handling massive datasets.

"""