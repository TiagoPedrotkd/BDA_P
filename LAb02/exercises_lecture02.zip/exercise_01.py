# Notebook 1: Speed Difference Between RAM and Disk

import time
import numpy as np
import pickle

# Create a large NumPy array
large_array = np.random.rand(1000000)

# Measure time to access data in RAM
start_time = time.time()
ram_data = large_array[:100000]  # Access first 100,000 elements
ram_time = time.time() - start_time
print(f"Time taken to access data in RAM: {ram_time:.6f} seconds")

# Save data to disk using Pickle
with open("large_array.pkl", "wb") as f:
    pickle.dump(large_array, f)

# Measure time to access data from disk
start_time = time.time()
with open("large_array.pkl", "rb") as f:
    disk_data = pickle.load(f)[:100000]
disk_time = time.time() - start_time
print(f"Time taken to access data from Disk: {disk_time:.6f} seconds")

# Notebook Explanation:
# - This notebook compares the speed of accessing data stored in RAM vs. loading it from disk.
# - You should see RAM access is significantly faster than disk access.
