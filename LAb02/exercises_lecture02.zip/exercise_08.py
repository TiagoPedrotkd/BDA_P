# Notebook 8: CPU vs GPU Processing

import time
import numpy as np
import cupy as cp  # CuPy is used for GPU processing

# Function to perform a large matrix computation
size = 10000  # Matrix size
A_cpu = np.random.rand(size, size)
B_cpu = np.random.rand(size, size)

# CPU Computation
print("Running on CPU...")
start_time = time.time()
C_cpu = np.dot(A_cpu, B_cpu)
end_time = time.time()
print(f"CPU execution time: {end_time - start_time:.2f} seconds")

# GPU Computation
A_gpu = cp.random.rand(size, size)
B_gpu = cp.random.rand(size, size)

print("\nRunning on GPU...")
start_time = time.time()
C_gpu = cp.dot(A_gpu, B_gpu)
cp.cuda.Device(0).synchronize()  # Ensure computation is completed
end_time = time.time()
print(f"GPU execution time: {end_time - start_time:.2f} seconds")

# Notebook Explanation:
# - This notebook compares CPU and GPU performance for matrix multiplication.
# - NumPy runs computations on the CPU, while CuPy runs on the GPU.
# - GPU can handle parallel computations much faster for large-scale tasks.