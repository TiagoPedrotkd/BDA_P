# Notebook 2: Persistence - RAM vs Disk

import numpy as np
import pickle

# Create a small dataset
small_array = np.random.rand(10)
print("Original Data:", small_array)

# Store data in RAM (temporary storage)
ram_data = small_array

# Store data on disk (permanent storage)
with open("small_array.pkl", "wb") as f:
    pickle.dump(small_array, f)

# Simulate shutting down the program (RAM data lost)
del ram_data

# Try to retrieve from RAM (will fail)
try:
    print("RAM Data:", ram_data)
except NameError:
    print("RAM data is lost after shutdown.")

# Retrieve from disk (will succeed)
with open("small_array.pkl", "rb") as f:
    disk_data = pickle.load(f)
print("Retrieved from Disk:", disk_data)

# Notebook Explanation:
# - This notebook demonstrates that RAM stores data temporarily, and data is lost after shutdown.
# - Data stored on disk persists even after the program is closed.
